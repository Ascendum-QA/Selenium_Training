package PageObjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Paytm_Recharge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = new File("C:/Junit-Paytm WS/Junit-Paytm/src/Paytm/Junit.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		WebDriver driver= new FirefoxDriver();
		//Open Paytm
		driver.get(prop.getProperty("URL"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Enter Mobile Number
		driver.findElement(By.xpath("//input[contains(@id,'input_4')]")).click();
		driver.findElement(By.name("operatorName")).sendKeys("9900976691");
		driver.findElement(By.xpath("//input[contains(@id,'input_4')]")).click();
		driver.findElement(By.xpath("//input[contains(@id,'input_7')]")).sendKeys("100");
		//Click on Proceed to Recharge
		driver.findElement(By.xpath("//div[2]/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}

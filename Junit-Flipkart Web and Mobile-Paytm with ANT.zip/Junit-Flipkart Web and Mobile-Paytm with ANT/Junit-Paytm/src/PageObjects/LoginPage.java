package PageObjects;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

public class LoginPage {
 
    private static WebElement element = null;
 
 public static WebElement Login(WebDriver driver){
 
    element = driver.findElement(By.xpath("//li[8]/a"));
 
    return element;
 
    }
 public static WebElement LoginID(WebDriver driver){
	 
	    element = driver.findElement(By.xpath("//div[4]/div[2]/input"));
	 
	    return element;
	 
	    }
 public static WebElement Password(WebDriver driver){
	 
	    element = driver.findElement(By.xpath("//input[@type='password']"));
	 
	    return element;
	 
	    }
 public static WebElement LoginButton(WebDriver driver){
	 
	    element = driver.findElement(By.xpath("//div[7]/input"));
	 
	    return element;
	 
	    }
 
 public static WebElement lnk_LogOut(WebDriver driver){
 
    element = driver.findElement(By.id("account_logout"));
 
 return element;
 
    }
 
}



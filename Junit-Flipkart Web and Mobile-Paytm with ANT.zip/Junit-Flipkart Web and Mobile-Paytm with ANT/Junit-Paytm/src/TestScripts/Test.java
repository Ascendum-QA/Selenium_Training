package TestScripts;
import java.io.*;
class ReadTest
{
public static void main(String[] args)
{
  try 
  {
   File f1 = new File("C:/Banner/Java.txt");
   BufferedReader br = new BufferedReader(new FileReader(f1)) ;
   String str;
   while ((str=br.readLine())!=null)
   {
    System.out.println(str);
   }
   br.close();
   
  }
  catch (IOException  e)
  { e.printStackTrace(); }
}
}

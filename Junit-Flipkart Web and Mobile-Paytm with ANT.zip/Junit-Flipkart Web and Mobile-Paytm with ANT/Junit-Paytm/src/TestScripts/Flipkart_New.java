package TestScripts;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.pagefactory.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.server.SeleniumServer;


import PageObjects.LoginPage;

public class Flipkart_New {
	

	WebDriver driver = new FirefoxDriver();

	@Before
	public void setUp() throws Exception {
		driver.get("http://www.flipkart.com");
	}

	@Test
	public void Flipkart_Login() throws Exception {
		LoginPage.Login(driver).click();
	     //Enter Username and Password
	     LoginPage.LoginID(driver).sendKeys("9900976691");
	     LoginPage.Password(driver).sendKeys("Password!1");
	     //Click on Login Button
	     LoginPage.LoginButton(driver).click();
	     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	     //Enter Search Criteria
	     
	     
	     
	}
	

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}
}


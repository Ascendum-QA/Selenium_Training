package Mobile_Automation;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;



import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Paytm_Mobile {
	
	       public static AndroidDriver driver;
	       Dimension size;
	       CommandLine command = null;
	       @Before
	       
	       public void setupAppium() throws MalformedURLException{
	    	   
	    	
	    	   DesiredCapabilities ds=new DesiredCapabilities();
               ds.setCapability("deviceName", "SM-E700H");
               ds.setCapability("platformName", "Android");
               ds.setCapability("platformVersion", "4.4.2");
               //ds.setCapability("unicodeKeyboard", true);

               ds.setCapability("appPackage", "net.one97.paytm");
               ds.setCapability("appActivity", "net.one97.paytm.AJRJarvisSplash");
               driver=new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),ds);
               driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
               ds.setCapability(MobileCapabilityType.TAKES_SCREENSHOT, "true");

	              
	              
	       }

	@Test
	public void Paytm_Electronics() throws Exception{
	      //Click on Mobiles and Accessories
		driver.findElementByName("Electronics").click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Select one Computer 
		driver.findElementById("net.one97.paytm:id/content_thumbnail").click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Click on Buy now
		driver.findElementById("net.one97.paytm:id/pdp_no_offer_price").click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Take Screenshot
		File srcFiler=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(srcFiler, new File("Paytm_Electronics.jpeg"));
		//Quit Driver
		driver.quit();
			
			
	}
}

package Mobile_Automation;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

public class Flipkart_Login {
	 public static AndroidDriver driver;
	public void setupAppium() throws MalformedURLException{
	 	   
    	
	 	   DesiredCapabilities ds=new DesiredCapabilities();
	        ds.setCapability("deviceName", "SM-E700H");
	        ds.setCapability("platformName", "Android");
	        ds.setCapability("platformVersion", "4.4.2");
	        //ds.setCapability("unicodeKeyboard", true);

	        ds.setCapability("appPackage", "com.flipkart.android");
	        ds.setCapability("appActivity", "net.hockeyapp.android.UpdateActivity");
	        driver=new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),ds);
	        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	        ds.setCapability(MobileCapabilityType.TAKES_SCREENSHOT, "true");

	           
	           
	    }
	public void Flipkart_Login() throws Exception {
		
	     //Click on Image
		driver.findElementByName("Open Drawer").click();
	     System.out.println("Flipkart Opened");
	     
	     
	}
	public static void main(String args[]){
		
	}
}

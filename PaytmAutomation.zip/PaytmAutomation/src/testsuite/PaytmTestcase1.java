package testsuite;

import org.testng.annotations.Test;

import setup.StartAppiumServer;

public class PaytmTestcase1 {
	
	@Test(priority=1)
	public static void PaytmApplicatonLaunch() throws Exception
	{
		// Starting Appium Server and Launching Paytm application
		StartAppiumServer.server();
		PaytmAppTest.PaytmAppLaunch();
	}
	
	@Test(priority=2,dependsOnMethods="PaytmApplicatonLaunch")
	public static void PaytmLogin() throws InterruptedException
	{
		// Login to Paytm
		PaytmAppTest.PaytmLogin();
	}
	
	@Test(priority=3,dependsOnMethods="PaytmLogin")
	public static void PaytmItemCart() throws InterruptedException
	{
		// Adding Items to Cart
		PaytmAppTest.ItemAddtoCart();
	}
		
		
	@Test(priority=4,dependsOnMethods="PaytmItemCart")
	public static void PaytmLogout() throws InterruptedException
	{
		// Logout & Exit from Paytm 
		PaytmAppTest.PaytmLogout();
		PaytmAppTest.PaytmAppExit();
	}
		
		
	}



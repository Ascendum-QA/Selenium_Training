package testsuite;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageobjectrepo.PaytmHomepage;
import pageobjectrepo.PaytmLoginpage;

public class PaytmAppTest {
	
	private static AndroidDriver<MobileElement> driver;
	
	@BeforeMethod
	public static void PaytmAppLaunch() throws MalformedURLException, InterruptedException
	{
		System.out.println("Launching Paytm Application");
		DesiredCapabilities cap = new DesiredCapabilities();	
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,MobilePlatform.ANDROID);
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
		cap.setCapability(MobileCapabilityType.APP_PACKAGE, "net.one97.paytm");
		cap.setCapability(MobileCapabilityType.APP_ACTIVITY, "net.one97.paytm.AJRMainActivity");
		driver=new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MobileElement e = driver.findElement(By.name("Account"));
		boolean launch = e.isDisplayed();
		if(launch==true){
			System.out.println("Paytm application launch Successfull");
			Reporter.log("Paytm application launch Successfull");
		}
		else
		{
			System.out.println("Paytm application launch Unsuccessfull");
			Reporter.log("Paytm application launch Unsuccessfull");
		}
		
		Thread.sleep(5000);

}
	
	@Test(priority=1)
	public static void PaytmLogin() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("############# Login to Paytm Account #############");
		PaytmHomepage ph = new PaytmHomepage(driver);
		ph.Account().click();
		driver.findElement(By.id("net.one97.paytm:id/name")).click();
		Thread.sleep(500);
		PaytmLoginpage pl = new PaytmLoginpage(driver);
		pl.Emailid().sendKeys("9901804660");
		pl.Password().sendKeys("amma@123");
		pl.Login().click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		WebElement e = driver.findElement(By.name("Sign Out"));
		boolean signin = e.isDisplayed();
		if(signin==true){
			System.out.println("Paytm Login Successfull");
			Reporter.log("Paytm Login Successfull");
		}
		else
		{
			System.out.println("Paytm Login Unsuccessfull");
			Reporter.log("Paytm Login Unsuccessfull");
		}
}
	
	@Test(priority=2,dependsOnMethods="PaytmLogin")
	public static void ItemAddtoCart() throws InterruptedException
	{
		System.out.println("############# Item Adding to Paytm Cart #############");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		PaytmHomepage ph1 = new PaytmHomepage(driver);
		ph1.Home().click();
		Thread.sleep(5000);
		// Search for any item
		//driver.findElement(By.xpath("//*[@content-desc='Open navigation drawer']")).click();
		//driver.findElement(By.name("Men's Fashion")).click();
		//driver.findElement(By.name("The Men's Store")).click();
		//driver.findElement(By.name("Vans Gold Aviator Sunglass")).click();
		driver.findElement(By.id("net.one97.paytm:id/action_search")).click();
		driver.findElement(By.id("net.one97.paytm:id/search_src_text")).sendKeys("Sony Xperia Z2");
		driver.pressKeyCode(AndroidKeyCode.ENTER);
		Thread.sleep(5000);
		driver.scrollToExact("Sony Xperia Z2 (Black)").click();
		driver.findElement(By.id("net.one97.paytm:id/pdp_no_offer_price")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("net.one97.paytm:id/icon_cart")).click();
		Thread.sleep(5000);
		WebElement e = driver.findElement(By.name("1 Item in your Bag"));
		boolean cart = e.isDisplayed();
		if(cart==true){
			System.out.println("Item Added to Cart Successfull");
			Reporter.log("Item Added to Cart Successfull");
			for(int i=0;i<3;i++)
			{
					
					driver.pressKeyCode(AndroidKeyCode.BACK);
					Thread.sleep(5000);
				//driver.navigate().back();
				
				
			}
		}
		else
		{
			System.out.println("Item Added to Cart Unsuccessfull");
			Reporter.log("Item Added to Cart Unsuccessfull");
		}
}
	
	@Test(priority=3,dependsOnMethods="ItemAddtoCart")
	public static void PaytmLogout()
	{
		System.out.println("############# Logout from Paytm Account #############");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		PaytmHomepage ph = new PaytmHomepage(driver);
		ph.Account().click();
		driver.findElement(By.name("Sign Out")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		WebElement e = driver.findElement(By.name("App Feedback"));
		boolean signin = e.isDisplayed();
		if(signin==true){
			System.out.println("Paytm Logout Successfull");
			Reporter.log("Paytm Logout Successfull");
		}
		else
		{
			System.out.println("Paytm Logout Unsuccessfull");
			Reporter.log("Paytm Logout Unsuccessfull");
		}
}
	
	@AfterMethod
	public static void PaytmAppExit() throws InterruptedException
	{
		driver.pressKeyCode(AndroidKeyCode.HOME);
		System.out.println("####### Execution Completed ############");
	}
}

package pageobjectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaytmLoginpage {
	
	WebDriver driver;
	
	public PaytmLoginpage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By username = By.id("net.one97.paytm:id/edit_username");
	By password = By.id("net.one97.paytm:id/edit_password");
	By login = By.id("net.one97.paytm:id/lyt_sign_in_button");
	
	public WebElement Emailid()
	{
		return driver.findElement(username);
	}
	
	public WebElement Password()
	{
		return driver.findElement(password);
	}
	
	public WebElement Login()
	{
		return driver.findElement(login);
	}
	
	
	
	

	
	

}

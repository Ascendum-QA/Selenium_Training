package pageobjectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaytmHomepage {
	
WebDriver driver;
	
	public PaytmHomepage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By home = By.name("Home");
	By wallet = By.name("Wallet");
	By account = By.name("Account");
	By updates = By.name("Updates");
	By search = By.id("net.one97.paytm:id/action_search");
	By cart = By.id("net.one97.paytm:id/icon_cart");
	
	public WebElement Home()
	{
		return driver.findElement(home);
	}
	
	public WebElement Wallet()
	{
		return driver.findElement(wallet);
	}
	
	public WebElement Account()
	{
		return driver.findElement(account);
	}
	
	public WebElement Updates()
	{
		return driver.findElement(updates);
	}
	
	public WebElement Search()
	{
		return driver.findElement(search);
	}
	
	public WebElement AddtoCart()
	{
		return driver.findElement(cart);
	}

}

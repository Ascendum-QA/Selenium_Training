package setup;

import org.testng.annotations.BeforeSuite;

public class StartAppiumServer {
	
	@BeforeSuite
	public static void server() throws Exception
	{
		System.out.println("############# Starting Appium Server #############");
		Runtime.getRuntime().exec("cmd /c start C:\\startappium.bat");
		Thread.sleep(7000L);
	}

}
